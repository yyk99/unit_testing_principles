To run integration tests:

1. Use the script in DatabaseGenerationScript.sql to create the database.
2. Configure the tests to execute sequentially, not in parallel.